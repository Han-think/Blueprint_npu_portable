# small_launch_vehicle — print & assembly guide

**Process:** FDM
**Safety:** EDUCATIONAL DISPLAY MOCKUP — non-functional; do not treat as flight/operational hardware.

## 0. Print the fit coupon first
`fit_test_coupon.stl` — pin Ø6 + holes at [0.25] mm. Use the loosest hole that still grips.

## 1. Parts
- `p1_seg1_stage_1_combustion_chamber_display_dummy.stl` × 1 — Stage 1 Combustion Chamber Display Dummy (seg1) · bbox [150.0, 150.0, 150.0] mm · clearance 0.0 mm
- `p1_seg2_stage_1_combustion_chamber_display_dummy.stl` × 1 — Stage 1 Combustion Chamber Display Dummy (seg2) · bbox [150.0, 150.0, 150.0] mm · clearance 0.0 mm
- `p2_stage_1_bell_nozzle_display_shell.stl` × 1 — Stage 1 Bell Nozzle Display Shell · bbox [91.5, 84.0, 220.0] mm · clearance 0.0 mm
- `p3_turbopump_assembly_display_dummy.stl` × 1 — Turbopump Assembly Display Dummy · bbox [152.0, 156.4, 200.0] mm · clearance 0.0 mm
- `p4_seg1_propellant_tank_dummy__lox_.stl` × 1 — Propellant Tank Dummy (LOX) (seg1) · bbox [1199.9, 1199.9, 222.2] mm · clearance 0.25 mm
- `p4_seg2_propellant_tank_dummy__lox_.stl` × 1 — Propellant Tank Dummy (LOX) (seg2) · bbox [1199.9, 1199.9, 222.2] mm · clearance 0.25 mm
- `p4_seg3_propellant_tank_dummy__lox_.stl` × 1 — Propellant Tank Dummy (LOX) (seg3) · bbox [1199.9, 1290.8, 222.2] mm · clearance 0.25 mm
- `p4_seg4_propellant_tank_dummy__lox_.stl` × 1 — Propellant Tank Dummy (LOX) (seg4) · bbox [1270.9, 1381.5, 222.2] mm · clearance 0.25 mm
- `p4_seg5_propellant_tank_dummy__lox_.stl` × 1 — Propellant Tank Dummy (LOX) (seg5) · bbox [1333.6, 1391.8, 222.2] mm · clearance 0.25 mm
- `p4_seg6_propellant_tank_dummy__lox_.stl` × 1 — Propellant Tank Dummy (LOX) (seg6) · bbox [1335.5, 1381.5, 222.2] mm · clearance 0.25 mm
- `p4_seg7_propellant_tank_dummy__lox_.stl` × 1 — Propellant Tank Dummy (LOX) (seg7) · bbox [1310.1, 1310.1, 222.2] mm · clearance 0.25 mm
- `p4_seg8_propellant_tank_dummy__lox_.stl` × 1 — Propellant Tank Dummy (LOX) (seg8) · bbox [1199.9, 1199.9, 222.2] mm · clearance 0.25 mm
- `p4_seg9_propellant_tank_dummy__lox_.stl` × 1 — Propellant Tank Dummy (LOX) (seg9) · bbox [1199.9, 1199.9, 222.2] mm · clearance 0.25 mm
- `p5_propellant_tank_dummy__fuel_.stl` × 1 — Propellant Tank Dummy (Fuel) · bbox [45.8, 45.8, 130.0] mm · clearance 0.25 mm
- `p6_interstage_adapter___separation_datum.stl` × 1 — Interstage Adapter + Separation Datum · bbox [108.1, 71.8, 36.0] mm · clearance 0.25 mm
- `p7_seg1_stage_2_engine_display_dummy.stl` × 1 — Stage 2 Engine Display Dummy (seg1) · bbox [150.0, 150.0, 150.0] mm · clearance 0.0 mm
- `p7_seg2_stage_2_engine_display_dummy.stl` × 1 — Stage 2 Engine Display Dummy (seg2) · bbox [200.0, 150.0, 150.0] mm · clearance 0.0 mm
- `p8_seg1_payload_fairing_display_shell.stl` × 1 — Payload Fairing Display Shell (seg1) · bbox [1499.8, 1499.8, 222.2] mm · clearance 0.25 mm
- `p8_seg2_payload_fairing_display_shell.stl` × 1 — Payload Fairing Display Shell (seg2) · bbox [1499.8, 1499.8, 222.2] mm · clearance 0.25 mm
- `p8_seg3_payload_fairing_display_shell.stl` × 1 — Payload Fairing Display Shell (seg3) · bbox [1499.8, 1499.8, 222.2] mm · clearance 0.25 mm
- `p8_seg4_payload_fairing_display_shell.stl` × 1 — Payload Fairing Display Shell (seg4) · bbox [1499.8, 1499.8, 222.2] mm · clearance 0.25 mm
- `p8_seg5_payload_fairing_display_shell.stl` × 1 — Payload Fairing Display Shell (seg5) · bbox [1499.8, 1499.8, 222.2] mm · clearance 0.25 mm
- `p8_seg6_payload_fairing_display_shell.stl` × 1 — Payload Fairing Display Shell (seg6) · bbox [1499.8, 1499.8, 222.2] mm · clearance 0.25 mm
- `p8_seg7_payload_fairing_display_shell.stl` × 1 — Payload Fairing Display Shell (seg7) · bbox [1499.8, 1499.8, 222.2] mm · clearance 0.25 mm
- `p8_seg8_payload_fairing_display_shell.stl` × 1 — Payload Fairing Display Shell (seg8) · bbox [1499.8, 1499.8, 222.2] mm · clearance 0.25 mm
- `p8_seg9_payload_fairing_display_shell.stl` × 1 — Payload Fairing Display Shell (seg9) · bbox [1499.8, 1499.8, 222.2] mm · clearance 0.25 mm
- `p9_fin_set_x_4_display_mock.stl` × 1 — Fin Set x 4 Display Mock · bbox [200.0, 49.8, 19.8] mm · clearance 0.25 mm
- `p10_avionics_bay_mock_tray.stl` × 1 — Avionics Bay Mock Tray · bbox [150.0, 82.8, 20.0] mm · clearance 0.0 mm
- `p11_battery_power_display_module.stl` × 1 — Battery/Power Display Module · bbox [80.0, 60.0, 40.0] mm · clearance 0.0 mm
- `p12_seg1_recovery_bay_display_dummy.stl` × 1 — Recovery Bay Display Dummy (seg1) · bbox [150.0, 200.0, 150.0] mm · clearance 0.0 mm
- `p12_seg2_recovery_bay_display_dummy.stl` × 1 — Recovery Bay Display Dummy (seg2) · bbox [150.0, 200.0, 150.0] mm · clearance 0.0 mm
- `p13_seg1_integration_inspection_ring.stl` × 1 — Integration Inspection Ring (seg1) · bbox [200.0, 894.4, 150.0] mm · clearance 0.0 mm
- `p13_seg2_integration_inspection_ring.stl` × 1 — Integration Inspection Ring (seg2) · bbox [200.0, 1131.4, 150.0] mm · clearance 0.0 mm
- `p13_seg3_integration_inspection_ring.stl` × 1 — Integration Inspection Ring (seg3) · bbox [200.0, 1200.0, 150.0] mm · clearance 0.0 mm
- `p13_seg4_integration_inspection_ring.stl` × 1 — Integration Inspection Ring (seg4) · bbox [200.0, 1200.0, 150.0] mm · clearance 0.0 mm
- `p13_seg5_integration_inspection_ring.stl` × 1 — Integration Inspection Ring (seg5) · bbox [200.0, 1131.4, 150.0] mm · clearance 0.0 mm
- `p13_seg6_integration_inspection_ring.stl` × 1 — Integration Inspection Ring (seg6) · bbox [200.0, 894.4, 150.0] mm · clearance 0.0 mm

## 2. Assembly order
1. p4 → p6 (face, 0.25 mm) — mounting_datum: interstage_datum
2. p5 → p6 (face, 0.25 mm) — structural mate: interstage_datum
3. p5 → p8 (face, 0.25 mm) — structural mate: payload_fairing_attachment
4. p6 → p8 (face, 0.25 mm) — structural_support: fairing_attachment_ring
5. p8 → p6 (face, 0.25 mm) — structural_mating: interstage_datum
6. p9 → p6 (face, 0.25 mm) — mating: interstage_datum
7. p9 → p8 (face, 0.25 mm) — mating: payload_fairing_attach_datum
8. p1_seg1 → p1_seg2 (alignment_key, 0.2 mm) — print-segmentation coupler: 4× 6.0mm corner alignment keys join p1 segments along axis Z
9. p4_seg1 → p4_seg2 (alignment_key, 0.2 mm) — print-segmentation coupler: 4× 6.0mm corner alignment keys join p4 segments along axis Z
10. p4_seg2 → p4_seg3 (alignment_key, 0.2 mm) — print-segmentation coupler: 4× 6.0mm corner alignment keys join p4 segments along axis Z
11. p4_seg3 → p4_seg4 (alignment_key, 0.2 mm) — print-segmentation coupler: 4× 6.0mm corner alignment keys join p4 segments along axis Z
12. p4_seg4 → p4_seg5 (alignment_key, 0.2 mm) — print-segmentation coupler: 4× 6.0mm corner alignment keys join p4 segments along axis Z
13. p4_seg5 → p4_seg6 (alignment_key, 0.2 mm) — print-segmentation coupler: 4× 6.0mm corner alignment keys join p4 segments along axis Z
14. p4_seg6 → p4_seg7 (alignment_key, 0.2 mm) — print-segmentation coupler: 4× 6.0mm corner alignment keys join p4 segments along axis Z
15. p4_seg7 → p4_seg8 (alignment_key, 0.2 mm) — print-segmentation coupler: 4× 6.0mm corner alignment keys join p4 segments along axis Z
16. p4_seg8 → p4_seg9 (alignment_key, 0.2 mm) — print-segmentation coupler: 4× 6.0mm corner alignment keys join p4 segments along axis Z
17. p7_seg1 → p7_seg2 (alignment_key, 0.2 mm) — print-segmentation coupler: 4× 6.0mm corner alignment keys join p7 segments along axis Z
18. p8_seg1 → p8_seg2 (alignment_key, 0.2 mm) — print-segmentation coupler: 4× 6.0mm corner alignment keys join p8 segments along axis Z
19. p8_seg2 → p8_seg3 (alignment_key, 0.2 mm) — print-segmentation coupler: 4× 6.0mm corner alignment keys join p8 segments along axis Z
20. p8_seg3 → p8_seg4 (alignment_key, 0.2 mm) — print-segmentation coupler: 4× 6.0mm corner alignment keys join p8 segments along axis Z
21. p8_seg4 → p8_seg5 (alignment_key, 0.2 mm) — print-segmentation coupler: 4× 6.0mm corner alignment keys join p8 segments along axis Z
22. p8_seg5 → p8_seg6 (alignment_key, 0.2 mm) — print-segmentation coupler: 4× 6.0mm corner alignment keys join p8 segments along axis Z
23. p8_seg6 → p8_seg7 (alignment_key, 0.2 mm) — print-segmentation coupler: 4× 6.0mm corner alignment keys join p8 segments along axis Z
24. p8_seg7 → p8_seg8 (alignment_key, 0.2 mm) — print-segmentation coupler: 4× 6.0mm corner alignment keys join p8 segments along axis Z
25. p8_seg8 → p8_seg9 (alignment_key, 0.2 mm) — print-segmentation coupler: 4× 6.0mm corner alignment keys join p8 segments along axis Z
26. p12_seg1 → p12_seg2 (alignment_key, 0.2 mm) — print-segmentation coupler: 4× 6.0mm corner alignment keys join p12 segments along axis X
27. p13_seg1 → p13_seg2 (alignment_key, 0.2 mm) — print-segmentation coupler: 4× 6.0mm corner alignment keys join p13 segments along axis X
28. p13_seg2 → p13_seg3 (alignment_key, 0.2 mm) — print-segmentation coupler: 4× 6.0mm corner alignment keys join p13 segments along axis X
29. p13_seg3 → p13_seg4 (alignment_key, 0.2 mm) — print-segmentation coupler: 4× 6.0mm corner alignment keys join p13 segments along axis X
30. p13_seg4 → p13_seg5 (alignment_key, 0.2 mm) — print-segmentation coupler: 4× 6.0mm corner alignment keys join p13 segments along axis X
31. p13_seg5 → p13_seg6 (alignment_key, 0.2 mm) — print-segmentation coupler: 4× 6.0mm corner alignment keys join p13 segments along axis X

## 3. Hardware
- alignment key 6mm × 96