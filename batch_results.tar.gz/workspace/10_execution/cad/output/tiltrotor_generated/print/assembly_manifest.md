# tiltrotor — print & assembly guide

**Process:** FDM
**Safety:** Educational mock assembly for design review; verify all fits with the coupon before committing full prints.

## 0. Print the fit coupon first
`fit_test_coupon.stl` — pin Ø6 + holes at [0.25] mm. Use the loosest hole that still grips.

## 1. Parts
- `p1_seg1_center_fuselage_spine.stl` × 1 — Center Fuselage Spine (seg1) · bbox [250.0, 150.0, 200.0] mm · clearance 0.0 mm
- `p1_seg2_center_fuselage_spine.stl` × 1 — Center Fuselage Spine (seg2) · bbox [250.0, 150.0, 200.0] mm · clearance 0.0 mm
- `p1_seg3_center_fuselage_spine.stl` × 1 — Center Fuselage Spine (seg3) · bbox [250.0, 150.0, 200.0] mm · clearance 0.0 mm
- `p2_main_wing__2_piece_.stl` × 1 — Main Wing (2-piece) · bbox [189.8, 33.8, 42.0] mm · clearance 0.25 mm
- `p3_nacelle_assembly_x_2.stl` × 1 — Nacelle Assembly x 2 · bbox [67.2, 19.8, 150.0] mm · clearance 0.25 mm
- `p4_tilt_servo___linkage_x_2.stl` × 1 — Tilt Servo + Linkage x 2 · bbox [40.0, 28.0, 56.0] mm · clearance 0.0 mm
- `p5_v_tail_x_2__ruddervator_.stl` × 1 — V-Tail x 2 (Ruddervator) · bbox [92.0, 40.0, 38.8] mm · clearance 0.25 mm
- `p6_landing_gear__tri_.stl` × 1 — Landing Gear (Tri) · bbox [84.8, 59.9, 36.0] mm · clearance 0.25 mm
- `p7_battery_bay__slide_in_.stl` × 1 — Battery Bay (Slide-In) · bbox [94.8, 41.8, 30.0] mm · clearance 0.25 mm
- `p8_payload_nose_bay.stl` × 1 — Payload Nose Bay · bbox [80.0, 60.0, 50.0] mm · clearance 0.0 mm
- `p9_tilt_axis_harness___datum_service_bay.stl` × 1 — Tilt-Axis Harness + Datum Service Bay · bbox [190.0, 34.0, 42.0] mm · clearance 0.0 mm

## 2. Assembly order
1. p2 → p1 (face, 0.25 mm) — structural mate: fuselage_spine_mating_surface
2. p3 → p1 (face, 0.25 mm) — attachment point: Fuselage Spine Mount
3. p5 → p1 (face, 0.25 mm) — structural mate: Spar Socket
4. p6 → p1 (face, 0.25 mm) — mounting datum: Fuselage Landing Gear Mount Point
5. p7 → p1 (face, 0.25 mm) — mounting datum: Fuselage Mounting Plate
6. p1_seg1 → p1_seg2 (alignment_key, 0.2 mm) — print-segmentation coupler: 4× 6.0mm corner alignment keys join p1 segments along axis Z
7. p1_seg2 → p1_seg3 (alignment_key, 0.2 mm) — print-segmentation coupler: 4× 6.0mm corner alignment keys join p1 segments along axis Z

## 3. Hardware
- alignment key 6mm × 8