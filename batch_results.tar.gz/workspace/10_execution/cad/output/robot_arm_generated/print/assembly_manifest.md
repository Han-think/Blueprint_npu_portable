# robot_arm — print & assembly guide

**Process:** FDM
**Safety:** Educational mock assembly for design review; verify all fits with the coupon before committing full prints.

## 0. Print the fit coupon first
`fit_test_coupon.stl` — pin Ø6 + holes at [0.25] mm. Use the loosest hole that still grips.

## 1. Parts
- `p1_base_joint__j1_.stl` × 1 — Base Joint (J1) · bbox [155.0, 120.0, 60.0] mm · clearance 0.0 mm
- `p2_shoulder_joint__j2_.stl` × 1 — Shoulder Joint (J2) · bbox [92.0, 92.0, 52.0] mm · clearance 0.0 mm
- `p3_upper_arm__link_2_3_.stl` × 1 — Upper Arm (Link 2-3) · bbox [48.0, 36.0, 150.0] mm · clearance 0.0 mm
- `p4_elbow_joint__j3_.stl` × 1 — Elbow Joint (J3) · bbox [60.0, 60.0, 44.1] mm · clearance 0.0 mm
- `p5_forearm___wrist__j4_.stl` × 1 — Forearm + Wrist (J4) · bbox [60.0, 63.0, 250.0] mm · clearance 0.0 mm
- `p6_wrist_pitch__j5_.stl` × 1 — Wrist Pitch (J5) · bbox [60.0, 44.5, 60.0] mm · clearance 0.0 mm
- `p7_wrist_roll__j6_.stl` × 1 — Wrist Roll (J6) · bbox [55.6, 54.0, 46.0] mm · clearance 0.0 mm
- `p8_tool_flange___changer.stl` × 1 — Tool Flange + Changer · bbox [80.0, 80.0, 20.8] mm · clearance 0.0 mm
- `p9_cable_management_spine.stl` × 1 — Cable Management Spine · bbox [18.0, 18.0, 230.0] mm · clearance 0.0 mm
- `p10_replaceable_motor_module_set.stl` × 1 — Replaceable Motor Module Set · bbox [60.0, 40.0, 230.0] mm · clearance 0.0 mm
- `p11_encoder_cover___sensing_set.stl` × 1 — Encoder Cover + Sensing Set · bbox [30.3, 38.0, 10.8] mm · clearance 0.0 mm
- `p12_drive_electronics_bay.stl` × 1 — Drive Electronics Bay · bbox [80.0, 40.0, 30.0] mm · clearance 0.0 mm

## 2. Assembly order

## 3. Hardware