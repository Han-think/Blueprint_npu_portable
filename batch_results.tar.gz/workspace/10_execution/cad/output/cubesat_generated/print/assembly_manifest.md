# cubesat — print & assembly guide

**Process:** FDM
**Safety:** EDUCATIONAL DISPLAY MOCKUP — non-functional; do not treat as flight/operational hardware.

## 0. Print the fit coupon first
`fit_test_coupon.stl` — pin Ø6 + holes at [0.25] mm. Use the loosest hole that still grips.

## 1. Parts
- `p1_seg1_primary_structure__3u_.stl` × 1 — Primary Structure (3U) (seg1) · bbox [100.0, 100.0, 150.0] mm · clearance 0.0 mm
- `p1_seg2_primary_structure__3u_.stl` × 1 — Primary Structure (3U) (seg2) · bbox [100.0, 100.0, 150.0] mm · clearance 0.0 mm
- `p2_solar_panel_x_4__deploy_.stl` × 1 — Solar Panel x 4 (deploy) · bbox [200.0, 30.0, 1.0] mm · clearance 0.0 mm
- `p3_antenna_deployer_x_2.stl` × 1 — Antenna Deployer x 2 · bbox [30.0, 20.0, 5.0] mm · clearance 0.0 mm
- `p4_reaction_wheel_x_3.stl` × 1 — Reaction Wheel x 3 · bbox [60.0, 40.0, 20.0] mm · clearance 0.0 mm
- `p5_star_tracker_mount.stl` × 1 — Star Tracker Mount · bbox [60.0, 60.0, 11.2] mm · clearance 0.0 mm
- `p6_payload_optics_bench.stl` × 1 — Payload Optics Bench · bbox [90.0, 89.8, 14.8] mm · clearance 0.25 mm
- `p7_seg1_cold_gas_thruster_x_4.stl` × 1 — Cold Gas Thruster x 4 (seg1) · bbox [92.0, 92.0, 163.4] mm · clearance 0.0 mm
- `p7_seg2_cold_gas_thruster_x_4.stl` × 1 — Cold Gas Thruster x 4 (seg2) · bbox [92.0, 92.0, 163.4] mm · clearance 0.0 mm
- `p8_separation_spring_plate.stl` × 1 — Separation Spring Plate · bbox [30.0, 20.0, 5.0] mm · clearance 0.0 mm
- `p9_seg1_eps_solar_charging_module.stl` × 1 — EPS Solar Charging Module (seg1) · bbox [92.0, 92.0, 163.4] mm · clearance 0.0 mm
- `p9_seg2_eps_solar_charging_module.stl` × 1 — EPS Solar Charging Module (seg2) · bbox [92.0, 92.0, 163.4] mm · clearance 0.0 mm
- `p10_cdh_avionics_stack.stl` × 1 — CDH Avionics Stack · bbox [79.0, 30.0, 15.0] mm · clearance 0.0 mm
- `p11_seg1_thermal_path___radiator_strap_evidence.stl` × 1 — Thermal Path / Radiator Strap Evidence (seg1) · bbox [91.8, 91.8, 163.4] mm · clearance 0.25 mm
- `p11_seg2_thermal_path___radiator_strap_evidence.stl` × 1 — Thermal Path / Radiator Strap Evidence (seg2) · bbox [91.8, 91.8, 163.4] mm · clearance 0.25 mm
- `p12_integration_harness___datum_spine.stl` × 1 — Integration Harness + Datum Spine · bbox [30.0, 10.0, 20.0] mm · clearance 0.0 mm

## 2. Assembly order
1. p6 → p1 (face, 0.25 mm) — mounting: mounting_holes
2. p11 → p1 (face, 0.25 mm) — mounting_datum: structure_mounting_holes
3. p1_seg1 → p1_seg2 (alignment_key, 0.2 mm) — print-segmentation coupler: 4× 6.0mm corner alignment keys join p1 segments along axis Z
4. p7_seg1 → p7_seg2 (alignment_key, 0.2 mm) — print-segmentation coupler: 4× 6.0mm corner alignment keys join p7 segments along axis Z
5. p9_seg1 → p9_seg2 (alignment_key, 0.2 mm) — print-segmentation coupler: 4× 6.0mm corner alignment keys join p9 segments along axis Z
6. p11_seg1 → p11_seg2 (alignment_key, 0.2 mm) — print-segmentation coupler: 4× 6.0mm corner alignment keys join p11 segments along axis Z

## 3. Hardware
- alignment key 6mm × 16